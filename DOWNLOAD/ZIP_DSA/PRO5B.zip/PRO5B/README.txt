/*
visit: https://hemanthrajhemu.github.io  for more programs and output
*/